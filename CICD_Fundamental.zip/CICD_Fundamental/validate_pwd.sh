#!/bin/bash

read -p "Please enter password: " PASS

# Condition 1: Password must be at least 8 characters long
if [ ${#PASS} -lt 8 ]; then
    echo "Password must be at least 8 characters long!"
    exit 1
fi

# Condition 2: Password must contain at least one numeric character
if ! [[ "$PASS" =~ [0-9] ]]; then
    echo "Password must contain at least one numeric character!"
    exit 2
fi

# Condition 3: Password must contain at least one special character
if ! [[ "$PASS" =~ [@#$%*+=-] ]]; then
    echo "Password must contain at least one special character: : @,#,$,%,*,+,-,="
    exit 3
fi

echo "Password is valid"
